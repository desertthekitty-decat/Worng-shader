#version 120

uniform sampler2D colortex0;
uniform float frameTimeCounter;

varying vec2 texcoord;

void main() {
    vec2 uv = texcoord;

    // Goofy screen wobble - makes everything feel slightly seasick
    float wob = sin(uv.y * 40.0 + frameTimeCounter * 4.0) * 0.006;
    wob += cos(uv.x * 30.0 + frameTimeCounter * 3.0) * 0.006;
    uv.x += wob;
    uv.y += wob * 0.5;

    // Chromatic aberration, pulsing over time, for extra "horrible" flavor
    float aberration = 0.004 + 0.003 * sin(frameTimeCounter * 2.0);
    float r = texture2D(colortex0, uv + vec2(aberration, 0.0)).r;
    float g = texture2D(colortex0, uv).g;
    float b = texture2D(colortex0, uv - vec2(aberration, 0.0)).b;
    vec3 color = vec3(r, g, b);

    // The main event: partial color inversion (not full, so blocks don't
    // wash into the background and disappear)
    vec3 inverted = 1.0 - color;
    color = mix(color, inverted, 0.65);

    // Boost contrast a touch so block edges stay readable
    color = (color - 0.5) * 1.15 + 0.5;
    color = clamp(color, 0.0, 1.0);

    // Knock the brightness down just a touch so inverted skies/whites don't blow out
    color *= 0.9;
    color = pow(color, vec3(1.05));

    // Pulsing vignette of doom (kept gentle so corners aren't crushed dark)
    vec2 center = uv - 0.5;
    float pulse = 0.5 + 0.15 * sin(frameTimeCounter * 5.0);
    float vignette = 1.0 - dot(center, center) * pulse;
    color *= vignette;

    gl_FragColor = vec4(color, 1.0);
}
