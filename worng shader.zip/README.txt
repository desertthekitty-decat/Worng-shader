Goofy Invert Shader (Iris, Minecraft 1.21.1 Fabric)
====================================================

WHAT IT DOES
- Inverts all colors on screen (full negative-image effect)
- Adds a wobbly, seasick screen warp
- Adds pulsing chromatic aberration (RGB split)
- Adds a pulsing vignette

This is a joke/gag shader - it's meant to look ridiculous, not good.

INSTALLATION
1. Make sure you have Fabric 1.21.1 + Fabric API + Iris installed.
2. Open Minecraft, go to Options > Video Settings > Shader Packs > Open Shader Pack Folder.
   (Or manually go to .minecraft/shaderpacks/)
3. Drop the "GoofyInvertShader" folder (or this zip, unextracted) into that shaderpacks folder.
   - If you put in the .zip as-is, Iris will read it directly - no need to unzip.
4. In the Shader Packs menu, select "GoofyInvertShader" and hit Done.

Enjoy the chaos.
